---
img:
  src: /images/apple-watch-white-mockup.png
  #srcset: /images/apple-watch-white-mockup.png 320px, /images/apple-watch-white-mockup@2x.png 600px
  alt: A wearable device
---
